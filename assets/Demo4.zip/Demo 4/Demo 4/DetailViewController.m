//
//  DetailViewController.m
//  Demo 4
//
//  Created by Michael Vitrano on 10/3/14.
//  Copyright (c) 2014 Michael Vitrano. All rights reserved.
//

#import "DetailViewController.h"

@interface DetailViewController ()

@property (weak, nonatomic) IBOutlet UITextView *textView;

@property (nonatomic) NSInteger index;
@property (nonatomic) NSString *text;

@end

@implementation DetailViewController

- (instancetype)initWithIndex:(NSInteger)index
                         text:(NSString *)text
{
    if (self = [super initWithNibName:@"DetailViewController" bundle:nil]) {
        self.index = index;
        self.text = text;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = [NSString stringWithFormat:@"%ld", self.index];
    self.textView.text = self.text;
}

@end
