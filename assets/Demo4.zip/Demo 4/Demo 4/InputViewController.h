//
//  InputViewController.h
//  Demo 4
//
//  Created by Michael Vitrano on 9/30/14.
//  Copyright (c) 2014 Michael Vitrano. All rights reserved.
//

#import <UIKit/UIKit.h>

@class InputViewController;

@protocol InputViewControllerDelegate <NSObject>

- (void)inputViewController:(InputViewController *)inVc
          didFinishWithText:(NSString *)text;

- (void)inputViewControllerDidCancel:(InputViewController *)inVc;

@end

@interface InputViewController : UIViewController

@property (nonatomic, weak) id<InputViewControllerDelegate> delegate;

@end
