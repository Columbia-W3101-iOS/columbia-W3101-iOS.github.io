//
//  DetailViewController.h
//  Demo 4
//
//  Created by Michael Vitrano on 10/3/14.
//  Copyright (c) 2014 Michael Vitrano. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

- (instancetype)initWithIndex:(NSInteger)index
                         text:(NSString *)text;

@end
