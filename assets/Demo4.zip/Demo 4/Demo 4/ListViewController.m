//
//  ListViewController.m
//  Demo 4
//
//  Created by Michael Vitrano on 9/30/14.
//  Copyright (c) 2014 Michael Vitrano. All rights reserved.
//

#import "ListViewController.h"
#import "InputViewController.h"
#import "DetailViewController.h"

static NSString *const kListViewTableViewCelllReuseIdentifier = @"kListViewTableViewCelllReuseIdentifier";

@interface ListViewController () <UITableViewDelegate, UITableViewDataSource, InputViewControllerDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic) NSMutableArray *strings;

@end

@implementation ListViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    
    self.strings = [NSMutableArray array];
    
    [self.strings addObject:@"Hello"];
    [self.strings addObject:@"World"];
    
}

- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section
{
    return self.strings.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kListViewTableViewCelllReuseIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:kListViewTableViewCelllReuseIdentifier];
    }
    
    NSInteger row = indexPath.row;
    NSString *string = self.strings[row];
    
    cell.textLabel.text = string;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView
didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger index = indexPath.row;
    NSString *text = self.strings[index];
    DetailViewController *detailVC = [[DetailViewController alloc] initWithIndex:index
                                                                            text:text];
    
    [self.navigationController pushViewController:detailVC
                                         animated:YES];
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)inputViewController:(InputViewController *)inVc
          didFinishWithText:(NSString *)text
{
    [self.strings addObject:text];
    [self.tableView reloadData];
    
    [self dismissViewControllerAnimated:YES
                             completion:nil];
}

- (void)inputViewControllerDidCancel:(InputViewController *)inVc
{
    [self dismissViewControllerAnimated:YES
                             completion:nil];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue
                 sender:(id)sender
{
    if ([segue.identifier isEqualToString:@"ListToInput"]) {
        InputViewController *inputVC = segue.destinationViewController;
        inputVC.delegate = self;
    }
}

@end
