//
//  InputViewController.m
//  Demo 4
//
//  Created by Michael Vitrano on 9/30/14.
//  Copyright (c) 2014 Michael Vitrano. All rights reserved.
//

#import "InputViewController.h"

@interface InputViewController ()

@property (weak, nonatomic) IBOutlet UITextField *textField;

@end

@implementation InputViewController

- (IBAction)doneButtonPressed:(id)sender
{
    if ([self.textField.text isEqualToString:@""] || self.textField.text == nil) {
        [self.delegate inputViewControllerDidCancel:self];
    } else {
        [self.delegate inputViewController:self
                         didFinishWithText:self.textField.text];
    }
}

@end
