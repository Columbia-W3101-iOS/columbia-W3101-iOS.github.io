//
//  MSVCalculator.h
//  CalcTest
//
//  Created by Michael Vitrano on 3/24/14.
//  Copyright (c) 2014 Rebus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MSVCalculator : NSObject

- (void)pushNumber:(int)number;

- (void)pushOperator:(NSString *)operatorString;

- (int)evaluate;

- (void)clear;

@end
