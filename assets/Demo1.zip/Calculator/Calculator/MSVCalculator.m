//
//  MSVCalculator.m
//  CalcTest
//
//  Created by Michael Vitrano on 3/24/14.
//  Copyright (c) 2014 Rebus. All rights reserved.
//

#import "MSVCalculator.h"

@interface MSVCalculator ()

@property (nonatomic) BOOL hasFirstOperand;

@property (nonatomic) int firstOperand;
@property (nonatomic) int secondOperand;

@property (nonatomic) NSString *operator;

@end

@implementation MSVCalculator

- (void)pushNumber:(int)number
{
    if (self.hasFirstOperand) {
        self.secondOperand = number;
    } else {
        self.firstOperand = number;
        
        self.hasFirstOperand = YES;
    }
}

- (void)pushOperator:(NSString *)operatorString
{
    self.operator = operatorString;
}

- (int)evaluate
{
    int val;
    
    if ([self.operator isEqualToString:@"+"]) {
        val = self.firstOperand + self.secondOperand;
    } else if ([self.operator isEqualToString:@"-"]) {
        val = self.firstOperand - self.secondOperand;
    } else if ([self.operator isEqualToString:@"*"]) {
        val = self.firstOperand * self.secondOperand;
    } else if ([self.operator isEqualToString:@"/"]) {
        val = self.firstOperand / self.secondOperand;
    }
    
    self.operator = nil;
    self.secondOperand = 0;
    self.firstOperand = val;
    
    return val;
}

- (void)clear
{
    self.hasFirstOperand = NO;
    self.firstOperand = 0;
    self.secondOperand = 0;
    self.operator = nil;
}

@end
