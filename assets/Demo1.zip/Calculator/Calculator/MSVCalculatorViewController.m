//
//  MSVCalculatorViewController.m
//  Calculator
//
//  Created by Michael Vitrano on 3/25/14.
//  Copyright (c) 2014 Vitrano. All rights reserved.
//

#import "MSVCalculatorViewController.h"
#import "MSVCalculator.h"

@interface MSVCalculatorViewController ()

@property (weak, nonatomic) IBOutlet UILabel *label;

@property (nonatomic) MSVCalculator *calculator;

@end

@implementation MSVCalculatorViewController

- (MSVCalculator *)calculator
{
    if (!_calculator) {
        _calculator = [[MSVCalculator alloc] init];
    }
    
    return _calculator;
}

- (IBAction)digitPressed:(UIButton *)sender
{
    NSString *digit = sender.currentTitle;
    NSLog(@"Digit Pressed: %@", digit);

    NSString *currentLabelContents = self.label.text;
    
    self.label.text = [currentLabelContents stringByAppendingString:digit];
}

- (IBAction)operatorPressed:(UIButton *)sender
{
    NSString *currentDigitString = self.label.text;
    NSString *operator = sender.currentTitle;
    
    int number = [currentDigitString intValue];
    
    [self.calculator pushNumber:number];
    [self.calculator pushOperator:operator];
    
    self.label.text = @"0";
}

- (IBAction)equalPressed:(id)sender
{
    int number = self.label.text.intValue;
    [self.calculator pushNumber:number];
    
    int val = [self.calculator evaluate];
    
    self.label.text = [NSString stringWithFormat:@"%d", val];
}

- (IBAction)clearPressed:(id)sender
{


}

@end
