//
//  Calculator.m
//  Calculator
//
//  Created by Michael Vitrano on 9/9/14.
//  Copyright (c) 2014 Michael Vitrano. All rights reserved.
//

#import "Calculator.h"

@interface Calculator ()

@property (nonatomic) NSInteger firstOperand;
@property (nonatomic) NSInteger secondOperand;

@property (nonatomic) BOOL firstOperandFull;

@property (nonatomic) NSString *operator;

@end

@implementation Calculator

- (void)pushOperand:(NSInteger)operand
{
    if (self.firstOperandFull) {
        self.secondOperand = operand;
    } else {
        self.firstOperand = operand;
        self.firstOperandFull = YES;
    }
}

- (void)pushOperator:(NSString *)operator
{
    self.operator = operator;
}

- (NSInteger)evaluate
{
    NSInteger finalResult;
    
    if ([self.operator isEqualToString:@"+"]) {
        finalResult = self.firstOperand + self.secondOperand;
    } else if ([self.operator isEqualToString:@"-"]) {
        finalResult = self.firstOperand - self.secondOperand;
    } else if ([self.operator isEqualToString:@"/"]) {
        finalResult = self.firstOperand / self.secondOperand;
    } else if ([self.operator isEqualToString:@"*"]) {
        finalResult = self.firstOperand * self.secondOperand;
    }
    
    self.firstOperand = finalResult;
    self.secondOperand = 0;
    self.firstOperandFull = NO;
    
    return finalResult;
}

- (void)clear
{
    self.firstOperand = 0;
    self.secondOperand = 0;
    self.firstOperandFull = NO;
}

@end
