//
//  ViewController.m
//  Calculator
//
//  Created by Michael Vitrano on 9/9/14.
//  Copyright (c) 2014 Michael Vitrano. All rights reserved.
//

#import "ViewController.h"
#import "Calculator.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *label;
@property (nonatomic) Calculator *calculator;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.calculator = [[Calculator alloc] init];
    
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)digitButtonPressed:(UIButton *)sender
{
    if ([self.label.text isEqualToString:@"0"]) {
        self.label.text = [sender titleForState:UIControlStateNormal];
    } else {
        self.label.text = [self.label.text stringByAppendingString:[sender titleForState:UIControlStateNormal]];
    }
}

- (IBAction)operatorButtonPressed:(UIButton *)sender
{
    NSInteger operand = [self.label.text integerValue];
    [self.calculator pushOperand:operand];
    [self.calculator pushOperator:[sender titleForState:UIControlStateNormal]];
    self.label.text = @"0";
}

- (IBAction)computeButtonPressed:(UIButton *)sender
{
    NSInteger operand = [self.label.text integerValue];
    [self.calculator pushOperand:operand];
    NSInteger value = [self.calculator evaluate];
    self.label.text = [NSString stringWithFormat:@"%ld",(long)value];
}

- (IBAction)clearButtonPressed:(UIButton *)sender
{
    [self.calculator clear];
    self.label.text = @"0";
}

@end
