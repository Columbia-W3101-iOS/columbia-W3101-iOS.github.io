//
//  ViewController.m
//  GCD Test
//
//  Created by Michael Vitrano on 10/7/14.
//  Copyright (c) 2014 Michael Vitrano. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@end

@implementation ViewController

- (IBAction)loadImagePressed:(UIButton *)sender
{
    sender.enabled = NO;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSURL *url = [NSURL URLWithString:@"http://upload.wikimedia.org/wikipedia/commons/d/df/NYC_Empire_State_Building.jpg"];
        
        NSData *imageData = [NSData dataWithContentsOfURL:url];
        
        NSString *docsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];

        NSUUID *uuid = [NSUUID UUID];
        
        NSString *fullPath = [docsPath stringByAppendingPathComponent:[uuid UUIDString]];
        
        [imageData writeToFile:fullPath atomically:YES];
        
        NSData *loadedImageData = [[NSData alloc] initWithContentsOfFile:fullPath];
        
        UIImage *image = [UIImage imageWithData:loadedImageData];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.image = image;
            sender.enabled = YES;
            NSLog(@"done loading");
        });
    });
}

- (IBAction)backgroundButtonPressed:(UIButton *)sender
{
    NSLog(@"background button pressed");
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"toAddController"]) {

    }
}

@end
