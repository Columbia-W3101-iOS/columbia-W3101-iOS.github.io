//
//  MSVDemoViewController.m
//  GCDTest
//
//  Created by Michael Vitrano on 4/22/14.
//  Copyright (c) 2014 Vitrano. All rights reserved.
//

#import "MSVDemoViewController.h"

@interface MSVDemoViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation MSVDemoViewController


- (IBAction)loadImage:(id)sender
{

    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSURL *url = [NSURL URLWithString:@"http://upload.wikimedia.org/wikipedia/commons/d/df/NYC_Empire_State_Building.jpg"];
        NSData *imageData = [NSData dataWithContentsOfURL:url];
        UIImage *image =[UIImage imageWithData:imageData];
        
        // Note the change from NSDocumentationDirectory to NSDocumentDirectory
        NSString *docPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
        
        NSUUID *uuid = [NSUUID UUID];
        
        NSString *imagePath = [docPath stringByAppendingPathComponent:[uuid UUIDString]];
        
        // Note the change from NSURL URLWithString: to fileURLWithPath:
        NSURL *imageURL = [NSURL fileURLWithPath:imagePath];
        
        [imageData writeToURL:imageURL atomically:YES];
        
        imageData = [NSData dataWithContentsOfURL:imageURL];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            self.imageView.image = image;
        });
    });

}

@end
