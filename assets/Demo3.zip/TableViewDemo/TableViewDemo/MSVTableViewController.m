//
//  MSVTableViewController.m
//  TableViewDemo
//
//  Created by Michael Vitrano on 4/8/14.
//  Copyright (c) 2014 Vitrano. All rights reserved.
//

#import "MSVTableViewController.h"

@interface MSVTableViewController () <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic) NSInteger rowCount;

@end

@implementation MSVTableViewController

- (void)loadView
{
    [super loadView];
    
    UITableView *tableView = [[UITableView alloc] initWithFrame:self.view.bounds
                                                          style:UITableViewStylePlain];
    tableView.dataSource = self;
    tableView.delegate = self;
    [self.view addSubview:tableView];
    self.tableView = tableView;
    
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.rowCount = 20;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.rowCount;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellReuseIdentifer"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cellReuseIdentifer"];
        
        NSLog(@"Allocating new cell");
    }

    cell.textLabel.text = [NSString stringWithFormat:@"%d", indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.rowCount++;
    
    [tableView beginUpdates];
    
    NSArray *insertArray = @[[NSIndexPath indexPathForRow:(indexPath.row) inSection:0]];
    [tableView insertRowsAtIndexPaths:insertArray withRowAnimation:UITableViewRowAnimationTop];
    
    NSArray *visiblePaths = [tableView indexPathsForVisibleRows];
    NSMutableArray *reloadArray = [NSMutableArray array];
    for (NSIndexPath *visiblePath in visiblePaths) {
        if (visiblePath.row > indexPath.row) {
            [reloadArray addObject:visiblePath];
        }
    }
    
    [tableView reloadRowsAtIndexPaths:reloadArray withRowAnimation:UITableViewRowAnimationFade];
    
    [tableView endUpdates];
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
