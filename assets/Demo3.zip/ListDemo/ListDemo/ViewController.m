//
//  ViewController.m
//  ListDemo
//
//  Created by Michael Vitrano on 9/23/14.
//  Copyright (c) 2014 Michael Vitrano. All rights reserved.
//

#import "ViewController.h"

static NSString *const kTableViewCellReuseIdentifier = @"kTableViewCellReuseIdentifier";

@interface ViewController () <UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@property (nonatomic) NSMutableArray *dates;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.dates = [NSMutableArray array];

    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
}

#pragma mark - UITableViewDataSource Methods

- (NSInteger)tableView:(UITableView *)tableView
 numberOfRowsInSection:(NSInteger)section
{
    return self.dates.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kTableViewCellReuseIdentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                      reuseIdentifier:kTableViewCellReuseIdentifier];
    }
    
    NSInteger row = [indexPath row];
    NSDate *dateForRow = self.dates[row];
    cell.textLabel.text = [NSString stringWithFormat:@"%@", dateForRow];
    
    return cell;
}

#pragma mark - Interface Actions

- (IBAction)addRowButtonPressed:(id)sender
{
    [self.dates addObject:[NSDate date]];
    
    NSInteger rowToAdd = self.dates.count - 1;
    NSIndexPath *path = [NSIndexPath indexPathForRow:rowToAdd inSection:0];
    
    [self.tableView insertRowsAtIndexPaths:@[path]
                          withRowAnimation:UITableViewRowAnimationTop];
    

}

@end
