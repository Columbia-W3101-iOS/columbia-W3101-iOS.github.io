//
//  MSVAppDelegate.h
//  PhotoEditor
//
//  Created by Michael Vitrano on 4/29/14.
//  Copyright (c) 2014 Vitrano. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MSVAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
