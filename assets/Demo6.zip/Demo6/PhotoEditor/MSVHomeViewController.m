//
//  MSVHomeViewController.m
//  PhotoEditor
//
//  Created by Michael Vitrano on 4/29/14.
//  Copyright (c) 2014 Vitrano. All rights reserved.
//

#import "MSVHomeViewController.h"
#import <AviarySDK/AviarySDK.h>

@interface MSVHomeViewController () <UINavigationControllerDelegate, UIImagePickerControllerDelegate, AFPhotoEditorControllerDelegate>

@property (weak, nonatomic) IBOutlet UIButton *chooseImageButton;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@end

@implementation MSVHomeViewController

- (void)dealloc
{
    // Deregister for notifications
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (instancetype)init
{
    if (self = [self initWithNibName:@"MSVHomeViewController" bundle:nil]) {
        [AFPhotoEditorController setAPIKey:@"756153788a5d8463"
                                    secret:@"206b099b8236dbf3"];
        
        // Registering for keyboard notifications
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(keyboardWillAppearNotification:)
                                                     name:UIKeyboardWillShowNotification
                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(keyboardWillDisappearNotification:)
                                                     name:UIKeyboardWillHideNotification
                                                   object:nil];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    UIImage *cameraImage = [UIImage imageNamed:@"camera"];
    
    [self.chooseImageButton setTitle:nil forState:UIControlStateNormal];
    [self.chooseImageButton setImage:cameraImage forState:UIControlStateNormal];
    
    [self.chooseImageButton setTintColor:[UIColor redColor]];
    
    self.imageView.contentMode = UIViewContentModeScaleAspectFit;
}

#pragma mark - Interface Actions

- (IBAction)cameraButtonPressed:(UIButton *)sender
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    [imagePicker setSourceType:UIImagePickerControllerSourceTypeSavedPhotosAlbum];
    [imagePicker setDelegate:self];
    
    [self presentViewController:imagePicker
                       animated:YES
                     completion:nil];
}

- (IBAction)textFieldDidFinish:(UITextField *)sender
{
    if (self.imageView.image && sender.text) {
        UIImage *imageToSave = self.imageView.image;
        NSString *filename = [sender.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSData *imageData = UIImageJPEGRepresentation(imageToSave, 1.0f);
            
            NSString *docPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
            
            NSString *imagePath = [docPath stringByAppendingPathComponent:filename];
            
            NSURL *imageURL = [NSURL fileURLWithPath:imagePath];
            
            if ([imageData writeToURL:imageURL atomically:YES]) {
                NSLog(@"file successfully written to %@", imagePath);
            }
        });
    }
}

#pragma mark - Keyboard Notifications

- (void)keyboardWillAppearNotification:(NSNotification *)notification
{
    NSDictionary *dictionary = [notification userInfo];
    CGRect keyboardFrame = [dictionary[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    // We adjust the frame of the scroll view so that it will not be under the
    // keyboard
    CGRect scrollViewFrame = self.scrollView.frame;
    scrollViewFrame.size.height -= CGRectGetHeight(keyboardFrame);
    
    self.scrollView.frame = scrollViewFrame;
}

- (void)keyboardWillDisappearNotification:(NSNotification *)notification
{
    // Reset the keyboard to its original position
    self.scrollView.frame = self.view.bounds;
}

#pragma mark - UIImagePickerController Delegate Methods

- (void)imagePickerController:(UIImagePickerController *)picker
didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    
    AFPhotoEditorController *editor = [[AFPhotoEditorController alloc] initWithImage:image];
    [editor setDelegate:self];
    
    [self dismissViewControllerAnimated:YES completion:^{
        [self presentViewController:editor animated:YES completion:nil];
    }];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - AFPhotoEditorControllerDelegate Methods

- (void)photoEditor:(AFPhotoEditorController *)editor finishedWithImage:(UIImage *)image
{
    self.imageView.image = image;
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)photoEditorCanceled:(AFPhotoEditorController *)editor
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
